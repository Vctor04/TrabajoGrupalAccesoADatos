package modelo;

public class BusquedaLibro {
    public TipoBusqueda tipo;
    public int id;
    public String titulo;
    public String autor;
    public String editorial;
    public int categoria;
    public int idSel=0;

}
