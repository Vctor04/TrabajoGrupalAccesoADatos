package modelo;

public abstract class Entidad {
    public abstract int getId();
}
