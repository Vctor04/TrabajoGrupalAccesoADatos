/**
 * Clases con las reglas de negocio de esta aplicación
 */
package modelo;