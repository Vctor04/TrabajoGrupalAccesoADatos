package modelo.dao;

import excepciones.CampoVacioExcepcion;
import modelo.LibroDTO;
import modelo.dao.helper.LogFile;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import singleton.HibernateUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Aquí implementaremos las reglas de negocio definidas
 * en la interfaz para trabajar con libro y  base de datos en MySQL
 * @author AGE
 * @version 3
 */
public class LibroDAOImpl implements LibroDAO {
    private final Session session = HibernateUtil.getSessionFactory().getCurrentSession();

    public LibroDAOImpl() {
    }

    @Override
    public boolean insertar(LibroDTO libro) throws Exception {
        Session sessionInsertar = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction transaction = null;
        boolean insertado;

        transaction = sessionInsertar.beginTransaction();
        sessionInsertar.save(libro);
        transaction.commit();
        insertado = true;

        grabaEnLogIns(libro);
        return insertado;
    }

    private void grabaEnLogIns(LibroDTO libro) throws Exception {
        String sql = "INSERT INTO libro (nombre, autor, editorial, categoria) VALUES (?, ?, ?, ?)";
        sql = sql.replaceFirst("\\?", libro.getNombre());
        sql = sql.replaceFirst("\\?", libro.getAutor());
        sql = sql.replaceFirst("\\?", libro.getEditorial());
        sql = sql.replaceFirst("\\?", String.valueOf(libro.getCategoria()));
        LogFile.saveLOG(sql);
    }

    @Override
    public boolean modificar(LibroDTO libro) throws Exception {
        Transaction transaction = null;
        boolean actualizado;

        transaction = session.beginTransaction();
        session.update(libro);
        transaction.commit();
        actualizado = true;
        grabaEnLogUpd(libro);
        return actualizado;
    }
    private void grabaEnLogUpd(LibroDTO libro) throws Exception {
        String sql = "UPDATE libro SET nombre=?, autor=?, editorial=?, categoria=? WHERE id = ?";
        sql = sql.replaceFirst("\\?", libro.getNombre());
        sql = sql.replaceFirst("\\?", libro.getAutor());
        sql = sql.replaceFirst("\\?", libro.getEditorial());
        sql = sql.replaceFirst("\\?", String.valueOf(libro.getCategoria()));
        sql = sql.replaceFirst("\\?", String.valueOf(libro.getId()));
        LogFile.saveLOG(sql);
    }
    private void grabaEnLogDel(int id) throws Exception {
        String sql = "DELETE FROM libro WHERE id = ?";
        sql = sql.replaceFirst("\\?", String.valueOf(id));
        LogFile.saveLOG(sql);
    }

    @Override
    public boolean borrar(int id) throws Exception {
        Session sessionBorrar = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction transaction = null;
        boolean borrado = false;

        transaction = sessionBorrar.beginTransaction();
        LibroDTO libro = sessionBorrar.get(LibroDTO.class, id);
        if (libro != null) {
            sessionBorrar.delete(libro);
            transaction.commit();
            borrado = true;
        }
        grabaEnLogDel(id);
        return borrado;
    }

    /**
     * Este método estático devuelve todos los libros de la BD,
     * este método tendremos en un futuro reimplmentarlo por rangos de x,
     * para que el rendimiento no decaiga cuando la tabla crezca
     * @return un arraylist con todos los libros de la BD
     * @throws SQLException cualquier error asociado a la consulta sql
     * @throws CampoVacioExcepcion en el caso que contenga una categoria con categoria a null
     */
    @Override
    public List<LibroDTO> leerAllLibros() throws Exception {
        List<LibroDTO> lista = null;
        Transaction transaction = session.beginTransaction();
        lista = session.createQuery("FROM LibroDTO", LibroDTO.class).list();
        transaction.commit();
        LogFile.saveLOG("SELECT id,nombre,autor,editorial,categoria FROM libro");
        return lista;
    }

    /**
    * Este método estático devuelve todos los libros de la BD,
    * que cumplan la condición según los parametros
    * este método tendremos en un futuro reimplmentarlo por rangos de x,
    * para que el rendimiento no decaiga cuando la tabla crezca
    * @param id código de libro a buscar
    * @param titulo búsqueda de libros con dicho título
    * @param autor búsqueda de libros con dicho autor
    * @param editorial búsqueda de libros con dicha editorial
    * @param categoria búsqueda de libros con dicho de código de categoría
    * @return un arraylist con todos los libros de la BD
    * @throws SQLException cualquier error asociado a la consulta sql
    * @throws CampoVacioExcepcion en el caso que contenga una categoria con categoria a null
    * */
    @Override
    public List<LibroDTO> leerLibrosOR(int id, String titulo, String autor, String editorial, int categoria) throws Exception {
        List<LibroDTO> lista = null;

        StringBuilder hql = new StringBuilder("FROM LibroDTO WHERE ");
        List<String> condiciones = new ArrayList<>();

        if (id != 0) {
            condiciones.add("id = :id");
        }
        if (!titulo.trim().isEmpty()) {
            condiciones.add("nombre LIKE :titulo");
        }
        if (!autor.trim().isEmpty()) {
            condiciones.add("autor LIKE :autor");
        }
        if (!editorial.trim().isEmpty()) {
            condiciones.add("editorial LIKE :editorial");
        }
        if (categoria != 0) {
            condiciones.add("categoria = :categoria");
        }

        if (!condiciones.isEmpty()) {
            hql.append(String.join(" OR ", condiciones));

            Transaction transaction = session.beginTransaction();
            Query<LibroDTO> query = session.createQuery(hql.toString(), LibroDTO.class);

            if (id != 0) {
                query.setParameter("id", id);
            }
            if (!titulo.trim().isEmpty()) {
                query.setParameter("titulo", "%" + titulo + "%");
            }
            if (!autor.trim().isEmpty()) {
                query.setParameter("autor", "%" + autor + "%");
            }
            if (!editorial.trim().isEmpty()) {
                query.setParameter("editorial", "%" + editorial + "%");
            }
            if (categoria != 0) {
                query.setParameter("categoria", categoria);
            }

            lista = query.list();
            transaction.commit();

            LogFile.saveLOG("SELECT id,nombre,autor,editorial,categoria FROM LibroDTODTO WHERE " + hql.toString());
        }

        return lista;
    }

    /**
     * para instanciar un objeto libro a partir de un id
     * @param id clave primaria de la tabla libro
     * @return el objeto libro asociado a una clave primaria
     * @throws SQLException cualquier error asociado a la consulta sql
     * @throws CampoVacioExcepcion en el caso que contenga una libro con libro a null

     */
    @Override
    public LibroDTO getLibro(int id) throws Exception {
        LibroDTO libro = null;

            Transaction transaction = session.beginTransaction();
            libro = session.get(LibroDTO.class, id);
            transaction.commit();
            LogFile.saveLOG("SELECT id,nombre,autor,editorial,categoria FROM LibroDTO WHERE id = " + id);
        return libro;
    }
}
