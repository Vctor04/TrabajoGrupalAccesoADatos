package modelo.dao;

import modelo.PrestamosDTO;
import modelo.dao.helper.LogFile;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import singleton.HibernateUtil;


/**
 * Aquí implementaremos las reglas de negocio definidas
 * en la interfaz para trabajar con préstamos y
 * base de datos en MySQL
 * @author AGE
 * @version 2
 */
public class PrestamoDAOImpl implements PrestamoDAO {

    private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final Session session = HibernateUtil.getSessionFactory().getCurrentSession();

    @Override
    public boolean insertar(PrestamosDTO prestamo) throws Exception {
        boolean insertado = false;

        session.beginTransaction();
        session.save(prestamo);
        session.getTransaction().commit();
        insertado = true;

        grabaEnLogIns(prestamo);
        return insertado;
    }
    private void grabaEnLogIns(PrestamosDTO prestamo) throws Exception {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = null;

            try {
                transaction = session.beginTransaction();

                // Guardar el préstamo en la base de datos
                session.save(prestamo);

                transaction.commit();
            } catch (Exception e) {
                if (transaction != null && transaction.isActive()) {
                    transaction.rollback();
                }
                throw new Exception("Error al guardar el préstamo en la base de datos", e);
            }
        }
    }


    @Override
    public boolean modificar(PrestamosDTO prestamo) throws Exception {
        boolean actualizado = false;

        session.beginTransaction();
        session.update(prestamo);
        session.getTransaction().commit();
        actualizado = true;

        grabaEnLogUpd(prestamo);
        return actualizado;
    }
    private void grabaEnLogUpd(PrestamosDTO prestamo) throws Exception {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = null;

            try {
                transaction = session.beginTransaction();

                // Actualizar el préstamo en la base de datos
                session.update(prestamo);

                transaction.commit();
            } catch (Exception e) {
                if (transaction != null && transaction.isActive()) {
                    transaction.rollback();
                }
                throw new Exception("Error al actualizar el préstamo en la base de datos", e);
            }
        }
    }



    @Override
    public boolean borrar(int id) throws Exception {

        boolean borrado = false;
        try (Session sessionBorrar = HibernateUtil.getSessionFactory().getCurrentSession()){
            sessionBorrar.beginTransaction();
            PrestamosDTO prestamo = sessionBorrar.get(PrestamosDTO.class, id);
            if (prestamo != null) {
                sessionBorrar.delete(prestamo);
                borrado = true;
            }
            sessionBorrar.getTransaction().commit();
        } catch (Exception e) {
            throw e;
        }
        grabaEnLog(id);
        return borrado;
    }
    private void grabaEnLog(int id) throws Exception {
        String sql = String.format("DELETE FROM prestamos WHERE idPrestamo=%d", id);
        LogFile.saveLOG(sql);
    }

    /**
     * Este método estático devuelve todos los prestamoss de la BD,
     * este método tendremos en un futuro reimplmentarlo por rangos de x,
     * para que el rendimiento no decaiga cuando la tabla crezca
     * @return un arraylist con todos los prestamos de la BD
     * @throws Exception cualquier error asociado a la consulta sql, grabar en fichero...
     */
    @Override
    public List<PrestamosDTO> leerAllPrestamos() throws Exception {
        List<PrestamosDTO> lista = new ArrayList<>();

        session.beginTransaction();
        lista = session.createQuery("FROM PrestamosDTO", PrestamosDTO.class).getResultList();
        session.getTransaction().commit();
        return lista;
    }

    /**
     * Para instanciar un objeto préstamos a partir de un id
     * @param id clave primaria de la tabla préstamos
     * @return el objeto prestamos asociado a una clave primaria
     * @throws Exception cualquier error asociado a la consulta sql, grabar en fichero, ...
     */
    @Override
    public PrestamosDTO getPrestamo(int id) throws Exception {
        PrestamosDTO prestamo = null;

        session.beginTransaction();
        prestamo = session.get(PrestamosDTO.class, id);
        session.getTransaction().commit();

        return prestamo;
    }
}