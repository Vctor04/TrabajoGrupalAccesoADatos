package modelo.dao;


import modelo.HistoricoDTO;
import modelo.dao.helper.LogFile;
import org.hibernate.Session;
import org.hibernate.Transaction;
import singleton.Configuracion;
import singleton.HibernateUtil;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Aquí implementaremos las reglas de negocio definidas
 * en la interfaz para trabajar con historico y
 * base de datos en MySQL utilizando Hibernate
 * @author AGE
 * @version 2
 */
public class HistoricoDAOImpl implements HistoricoDAO {
    private HistoricoDTO historico;
    private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final Session session = HibernateUtil.getSessionFactory().getCurrentSession();

    public HistoricoDAOImpl(HistoricoDTO historico) {
        this.historico = historico;
    }

    @Override
    public HistoricoDTO getHistorico() {
        return historico;
    }

    @Override
    public boolean insertar() throws IOException {
        boolean insertado = false;
        Transaction transaction = null;
        LocalDate fechaActual = LocalDate.now();
        Timestamp timestamp = Timestamp.valueOf(fechaActual.atStartOfDay());

        try{
            transaction = session.beginTransaction();
            historico.setUser(Configuracion.getInstance().getUser());
            historico.setFecha(timestamp);
            historico.setInfo(historico.getInfo());

            session.save(historico);
            transaction.commit();
            insertado = true;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw new IOException("Error al insertar en la tabla Historico.", e);
        }
        grabaEnLogIns();
        return insertado;
    }

    private void grabaEnLogIns() throws IOException {
        String sql = "INSERT INTO historico (user, fecha, info) VALUES (?, ?, ?)";
        sql = sql.replaceFirst("\\?", String.valueOf(historico.getUser()));

        // Convertir java.sql.Timestamp a LocalDateTime si es necesario
        LocalDateTime fechaLocalDateTime = historico.getFecha().toLocalDateTime();

        sql = sql.replaceFirst("\\?", fechaLocalDateTime.format(formatter));
        sql = sql.replaceFirst("\\?", String.valueOf(historico.getInfo()));
        LogFile.saveLOGsinBD(sql);
    }

    /**
     * Este método inserta aquellos mensajes que son enviados al fichero LOG
     * pero que serán almacenados en la tabla Historico
     *
     * @param msgLog mensaje enviado para añadir a la tabla Historico
     * @throws IOException
     */
    public static void mensaje(String msgLog) throws IOException {
        HistoricoDTO historico = new HistoricoDTO();
        historico.setUser("UsuarioEjemplo"); // Ajusta esto según tu lógica para obtener el usuario.
        historico.setInfo(msgLog);
        new HistoricoDAOImpl(historico).insertar();
    }

}