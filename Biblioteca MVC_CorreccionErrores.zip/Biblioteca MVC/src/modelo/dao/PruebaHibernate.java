package modelo.dao;


import modelo.CategoriaDTO;
import modelo.LibroDTO;
import org.hibernate.proxy.pojo.bytebuddy.ByteBuddyInterceptor;
import singleton.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class PruebaHibernate {

    public static void main(String[] args) {
        Transaction transaction=null;
        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory(false).openSession();
            transaction = session.beginTransaction();

            System.out.println("Correctamente se ha conectado");

            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace(System.err);
            if (transaction!=null)
                transaction.rollback();
        } finally {
            if (session!=null)
                session.close();
        }

    }
}
