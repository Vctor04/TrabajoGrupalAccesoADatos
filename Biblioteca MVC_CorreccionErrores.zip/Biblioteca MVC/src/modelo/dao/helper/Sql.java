package modelo.dao.helper;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import singleton.ConexionMySQL;
import singleton.HibernateUtil;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.sql.*;
import java.util.List;

/**
 * Clase auxiliar con distintas funcionalidades a la hora de trabajar con SQL
 * @author AGE
 * @version 2
 */
public class Sql {
    /**
     * Prepara la parte where de una cláusula para concatenar condiciones usando el OR
     * @param where parte where actual antes de su ejecución
     * @param opcion condición a incluir en el futuro where
     * @return devuelve la parte where junto con la condición enviada y concatenada según una OR
     */
    public static String rellenaWhereOR(String where, String opcion) {
        if (!opcion.equals("")){
            if (where.equals(""))
                where=opcion;
            else where+=" OR "+opcion;
        }
        return where;
    }
    /**
     * Prepara la parte where de una cláusula para concatenar condiciones usando el AND
     * @param where parte where actual antes de su ejecución
     * @param opcion condición a incluir en el futuro where
     * @return devuelve la parte where junto con la condición enviada y concatenada según una AND
     */
    public static String rellenaWhereAND(String where, String opcion) {
        if (!opcion.equals("")){
            if (where.equals(""))
                where=opcion;
            else where+=" AND "+opcion;
        }
        return where;
    }
    /**
     * Permitirá grabar el contenido de una tabla en un fichero csv
     * dentro del path
     * @param path fichero donde se grabará el contenido de la tabla
     * @param tabla nombre de la tabla a importar
     * @param delimiter caracter delimitador
     */
    public static void importCSV(Path path, String tabla, char delimiter) throws Exception {
        String hql = "FROM " + tabla;
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            // Ejecutamos la consulta HQL
            List<Object[]> result = session.createQuery(hql).getResultList();

            // Escribimos la línea de la cabecera
            Object[] header = result.get(0);
            StringBuilder cabecera = new StringBuilder();
            for (int i = 0; i < header.length; i++) {
                cabecera.append(header[i]);
                if (i < header.length - 1) {
                    cabecera.append(delimiter);
                }
            }
            cabecera.append("\n");
            Files.writeString(path, cabecera.toString(), StandardCharsets.UTF_8, StandardOpenOption.CREATE);

            // Escribimos las filas
            for (Object[] row : result) {
                StringBuilder fila = new StringBuilder();
                for (int i = 0; i < row.length; i++) {
                    fila.append(row[i]);
                    if (i < row.length - 1) {
                        fila.append(delimiter);
                    }
                }
                fila.append("\n");
                Files.writeString(path, fila.toString(), StandardCharsets.UTF_8, StandardOpenOption.APPEND);
            }

            transaction.commit();
        }
    }
}
