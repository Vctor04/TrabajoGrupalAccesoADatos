package presentador;

import modelo.LibroDTO;

import java.util.List;

public interface VistaLibros extends VistaLibro{
    void setLibros(List<LibroDTO> listaLibros);
}
