package presentador;

import modelo.UsuarioDTO;

public interface VistaUsuario {
    void lanzar();
    void setPresentador(PresentadorUsuario presentador) throws Exception;
    UsuarioDTO getUsuario();

}
