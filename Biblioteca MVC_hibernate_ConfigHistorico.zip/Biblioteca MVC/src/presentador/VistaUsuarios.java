package presentador;

import modelo.UsuarioDTO;

import java.util.List;

public interface VistaUsuarios extends VistaUsuario{
    void setUsuarios(List<UsuarioDTO> listaUsuarios);
}
