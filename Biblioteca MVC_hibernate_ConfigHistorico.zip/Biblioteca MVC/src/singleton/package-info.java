/**
 * Clases de las que solo hay un único objeto instanciado en la aplicación
 */
package singleton;