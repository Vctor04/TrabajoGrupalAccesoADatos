/**
 * Para gestionar crear las excepciones personalizadas de la aplicación
 */
package excepciones;