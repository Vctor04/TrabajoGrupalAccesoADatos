/**
 * Contiene componentes reutilizables en los formularios
 * para agilizar la programación
 */
package vista.componentes;