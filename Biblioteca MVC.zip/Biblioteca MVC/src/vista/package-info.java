/**
 * Contiene todas los formularios realizadas en swing para la visualización de la aplicación
 */
package vista;