package presentador;


import modelo.CategoriaDTO;
import modelo.PrestamosDTO;

import java.util.List;

public interface VistaPrestamo {
    void lanzar();
    void setPresentador(PresentadorPrestamo presentador) throws Exception;
    PrestamosDTO getPrestamo();
    void setCategorias(List<CategoriaDTO> categorias);

}
