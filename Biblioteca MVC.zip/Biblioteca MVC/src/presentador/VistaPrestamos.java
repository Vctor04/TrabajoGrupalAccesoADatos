package presentador;

import modelo.PrestamosDTO;

import java.util.List;

public interface VistaPrestamos extends VistaPrestamo{
    void setPrestamos(List<PrestamosDTO> listaPrestamos);
}
