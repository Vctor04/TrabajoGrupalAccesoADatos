package presentador;


import modelo.CategoriaDTO;

public interface VistaCategoria {
    void lanzar();
    void setPresentador(PresentadorCategoria presentador) throws Exception;
    CategoriaDTO getCategoria();



}
