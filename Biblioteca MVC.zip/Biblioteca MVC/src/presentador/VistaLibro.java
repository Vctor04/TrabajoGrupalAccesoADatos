package presentador;



import modelo.CategoriaDTO;
import modelo.LibroDTO;

import java.util.List;

public interface VistaLibro {
    void lanzar();
    void setPresentador(PresentadorLibro presentador) throws Exception;
    LibroDTO getLibro();

    void setCategorias(List<CategoriaDTO> categorias);
}
