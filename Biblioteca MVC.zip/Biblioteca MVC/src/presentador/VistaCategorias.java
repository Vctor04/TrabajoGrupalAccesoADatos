package presentador;

import modelo.CategoriaDTO;

import java.util.List;

public interface VistaCategorias extends VistaCategoria{
    void setCategorias(List<CategoriaDTO> listaCategorias);
}
