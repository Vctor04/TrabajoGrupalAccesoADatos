package observer;

public class MainObserver {
    public static void main(String[] args) {
        EjemploObservable observable = new EjemploObservable();
        observable.addObserver(new PatronObserver());
        PatronObserver patronObserver = new PatronObserver();

        patronObserver.update("Has actualizado los libros");


    }
}
