package observer;


import modelo.CategoriaDTO;

import modelo.LibroDTO;

import modelo.PrestamosDTO;
import modelo.UsuarioDTO;

import java.util.List;

public interface Observer {
    void update();

    void updateLibro(List<LibroDTO> listaLibros);

    void updateCategoria(List<CategoriaDTO> listaCategorias);

    void updatePrestamos(List<PrestamosDTO> listaPrestamos);

    void updateUsuarios(List<UsuarioDTO> listaUsuario);
    void update(String mensaje);
}
