package observer;

import modelo.CategoriaDTO;

import modelo.LibroDTO;
import modelo.PrestamosDTO;
import modelo.UsuarioDTO;
import vista.*;

import javax.swing.*;
import java.util.List;

public class PatronObserver implements Observer {

    @Override
    public void update() {
    }

    @Override
    public void updateLibro(List<LibroDTO> listaLibros) {
        for (int i = 0; i < FormMain.getInstance().getDesktopPane().getComponentCount(); i++) {
            if (FormMain.getInstance().getDesktopPane().getComponent(i) instanceof ListaLibros) {
                ((ListaLibros) FormMain.getInstance().getDesktopPane().getComponent(i)).setLibros(listaLibros);
            }
        }
        System.out.println("Libros actualizados");
    }

    @Override
    public void updateCategoria(List<CategoriaDTO> listaCategorias) {
        for (int i=0;i< FormMain.getInstance().getDesktopPane().getComponentCount();i++){
            if (FormMain.getInstance().getDesktopPane().getComponent(i) instanceof  ListaCategorias){
                ((ListaCategorias) FormMain.getInstance().getDesktopPane().getComponent(i)).setCategorias(listaCategorias);
            }
        }
        System.out.println("Categorias actualizadas");
    }

    @Override
    public void updatePrestamos(List<PrestamosDTO> listaPrestamos) {
        for (int i = 0; i < FormMain.getInstance().getDesktopPane().getComponentCount(); i++) {
            if (FormMain.getInstance().getDesktopPane().getComponent(i) instanceof ListaPrestamos) {
                ((ListaPrestamos) FormMain.getInstance().getDesktopPane().getComponent(i)).setPrestamos(listaPrestamos);
            }
        }
        System.out.println("Prestamos actualizados");
    }

    @Override
    public void updateUsuarios(List<UsuarioDTO> listaUsuario) {
        for (int i = 0; i < FormMain.getInstance().getDesktopPane().getComponentCount(); i++) {
            if (FormMain.getInstance().getDesktopPane().getComponent(i) instanceof ListaUsuarios) {
                ((ListaUsuarios) FormMain.getInstance().getDesktopPane().getComponent(i)).setUsuarios(listaUsuario);
            }
        }
        System.out.println("Usuarios actualizados");
    }

    @Override
    public void update(String mensaje) {
        System.out.println(mensaje);
    }
}
