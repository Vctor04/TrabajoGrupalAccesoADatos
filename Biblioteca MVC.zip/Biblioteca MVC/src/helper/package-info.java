/**
 * Clases auxiliares entre otras: encriptar y desencriptar
 */
package helper;