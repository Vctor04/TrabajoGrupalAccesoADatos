package modelo.dao;

import excepciones.CampoVacioExcepcion;
import modelo.CategoriaDTO;
import modelo.UsuarioDTO;
import modelo.dao.helper.LogFile;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import singleton.HibernateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Aquí implementaremos las reglas de negocio definidas
 * en la interfaz para trabajar con categorías y
 * base de datos en MySQL
 * @author AGE
 * @version 2
 */
public class CategoriaDAOImpl implements CategoriaDAO {

    private final Session session = HibernateUtil.getSessionFactory().getCurrentSession();

    @Override
    public boolean inserta(CategoriaDTO categoria) throws Exception {
        Transaction transaction = null;
        boolean insertado;
        transaction = session.beginTransaction();
        session.save(categoria);
        transaction.commit();
        insertado = true;

        return insertado;
    }

    @Override
    public boolean modificar(CategoriaDTO categoria) throws Exception {
        Transaction transaction = null;
        boolean actualizado;

        transaction = session.beginTransaction();
        session.update(categoria);
        transaction.commit();
        actualizado = true;

        return actualizado;
    }

    @Override
    public boolean borrar(int id) throws Exception {
        Session sessionBorrar = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction transaction = null;
        boolean borrado = false;

        transaction = sessionBorrar.beginTransaction();
        CategoriaDTO categoria = sessionBorrar.get(CategoriaDTO.class, id);
        if (categoria != null) {
            sessionBorrar.delete(categoria);
            transaction.commit();
            borrado = true;
        }

        return borrado;
    }

    /**
     * el valor máximo del campo id de la tabla categorías
     * @return valor máximo del campo id
     * @throws Exception cualquier error asociado a la consulta sql
     */
    public static int maximaId() throws Exception {
        int maximo = 0;
        String sql = "SELECT MAX(id) AS max_id FROM CategoriaDTO";

        Query<?> query = HibernateUtil.getSessionFactory().getCurrentSession().createQuery(sql);
        maximo = (int) query.uniqueResult();

        return maximo;
    }

    /**
     * el valor mínimo del campo id de la tabla categorías
     * @return valor mínimo del campo id
     * @throws Exception cualquier error asociado a la consulta sql
     */
    public static int minimaId() throws Exception {
        int minimo = 0;
        String sql = "SELECT MIN(id) AS min_id FROM CategoriaDTO";

        Query<?> query = HibernateUtil.getSessionFactory().getCurrentSession().createQuery(sql);
        minimo = (int) query.uniqueResult();

        return minimo;
    }

    /**
     * para instanciar un objeto categoria a partir de un id
     * @param id clave primaria de la tabla categoria
     * @return el objeto categoría asociado a una clave primaria
     * @throws Exception cualquier error asociado a la consulta sql
     */
    @Override
    public CategoriaDTO categoria(int id) throws Exception {
        Session sessionConsulta = HibernateUtil.getSessionFactory().openSession();
        return sessionConsulta.get(CategoriaDTO.class, id);

    }

    /**
     * Este método estático devuelve todos las categorías de la BD,
     * este método tendremos en un futuro reimplmentarlo por rangos de x,
     * para que el rendimiento no decaiga cuando la tabla crezca
     * @return un arraylist con todos las categorias de la BD
     * @throws Exception cualquier error asociado a la consulta sql
     * @throws CampoVacioExcepcion en el caso que contenga una CategoriaDTO con categoria a null
     */
    public List<CategoriaDTO> leerAllCategorias() throws Exception {
        List<CategoriaDTO> lista = new ArrayList<>();
        Transaction transaction = null;

        Session sessionLeerCategorias = HibernateUtil.getSessionFactory().openSession();
        transaction = sessionLeerCategorias.beginTransaction();
        Query<CategoriaDTO> query = sessionLeerCategorias.createQuery("from CategoriaDTO", CategoriaDTO.class);
        lista = query.getResultList();
        transaction.commit();


        return lista;
    }

}
