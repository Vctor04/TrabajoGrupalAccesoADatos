/**
 * Implementación del modelo usando un patrón de diseño DAO
 */
package modelo.dao;
