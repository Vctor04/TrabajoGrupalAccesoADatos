package modelo.dao;

import java.util.ArrayList;
import java.util.List;

import modelo.UsuarioDTO;
import modelo.dao.helper.LogFile;
import org.hibernate.Session;
import singleton.HibernateUtil;

/**
 * Aquí implementaremos las reglas de negocio definidas
 * en la interfaz para trabajar con usuario y
 * base de datos en MySQL
 * @author AGE
 * @version 2
 */
public class UsuarioDAOImpl implements UsuarioDAO{
    private final Session session = HibernateUtil.getSessionFactory().getCurrentSession();

    @Override
    public boolean insertar(UsuarioDTO usuario) throws Exception {
        boolean bInsertado;

        session.beginTransaction();
        session.save(usuario);
        session.getTransaction().commit();
        bInsertado = true;

        grabaEnLogIns(usuario);
        return bInsertado;
    }

    private void grabaEnLogIns(UsuarioDTO usuario) throws Exception {
        String sql = String.format("INSERT INTO usuario (nombre, apellidos) VALUES ('%s', '%s')",
                usuario.getNombre(), usuario.getApellidos());
        LogFile.saveLOG(sql);
    }

    @Override
    public boolean modificar(UsuarioDTO usuario) throws Exception {
        boolean modificado;
        session.beginTransaction();
        session.update(usuario);
        session.getTransaction().commit();
        modificado = true;
        grabaEnLogUpd(usuario);
        return modificado;
    }
    private void grabaEnLogUpd(UsuarioDTO usuario) throws Exception {
        String sql = String.format("UPDATE usuario SET nombre='%s', apellidos='%s' WHERE id=%d",
                usuario.getNombre(), usuario.getApellidos(), usuario.getId());
        LogFile.saveLOG(sql);
    }


    @Override
    public boolean borrar(int id) throws Exception {
        boolean borrado=false;
        Session sessionBorrar = HibernateUtil.getSessionFactory().getCurrentSession();
        sessionBorrar.beginTransaction();
        UsuarioDTO usuario = sessionBorrar.get(UsuarioDTO.class, id);
        if (usuario != null) {
            sessionBorrar.delete(usuario);
            borrado = true;
        }
        sessionBorrar.getTransaction().commit();

        grabaEnLogDel(id);
        return borrado;
    }
    private void grabaEnLogDel(int id) throws Exception {
        String sql = String.format("DELETE FROM usuario WHERE id=%d", id);
        LogFile.saveLOG(sql);
    }

    @Override
    public List<UsuarioDTO> leerAllUsuarios() throws Exception {
        List<UsuarioDTO> lista = new ArrayList<>();

        session.beginTransaction();
        lista = session.createQuery("FROM UsuarioDTO", UsuarioDTO.class).getResultList();
        session.getTransaction().commit();

        return lista;
    }


    @Override
    public List<UsuarioDTO> leerUsuariosOR(int id, String nombre, String apellidos) throws Exception {
        List<UsuarioDTO> lista = new ArrayList<>();

        session.beginTransaction();
        String hql = "FROM Usuario WHERE ";
        boolean conditionAdded = false;

        if (id != 0) {
            hql += String.format("id = %d", id);
            conditionAdded = true;
        }

        if (!nombre.trim().equals("")) {
            if (conditionAdded) {
                hql += " OR ";
            }
            hql += String.format("nombre LIKE '%s'", nombre);
            conditionAdded = true;
        }

        if (!apellidos.trim().equals("")) {
            if (conditionAdded) {
                hql += " OR ";
            }
            hql += String.format("apellidos LIKE '%s'", apellidos);
        }

        lista = session.createQuery(hql, UsuarioDTO.class).getResultList();
        session.getTransaction().commit();

        return lista;
    }

    @Override
    public UsuarioDTO getUsuario(int id) throws Exception {
        UsuarioDTO usuario = null;

        session.beginTransaction();
        usuario = session.get(UsuarioDTO.class, id);
        session.getTransaction().commit();

        return usuario;
    }

}
