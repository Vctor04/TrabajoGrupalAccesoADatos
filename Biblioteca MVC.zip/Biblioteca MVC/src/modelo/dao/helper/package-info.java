/**
 * Clases auxiliares para trabajar con distintos motores de bases de datos
 */
package modelo.dao.helper;
