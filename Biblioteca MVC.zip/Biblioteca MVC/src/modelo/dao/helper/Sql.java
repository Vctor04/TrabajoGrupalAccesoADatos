package modelo.dao.helper;

import modelo.LibroDTO;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import singleton.ConexionMySQL;
import singleton.HibernateUtil;

import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.sql.*;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Clase auxiliar con distintas funcionalidades a la hora de trabajar con SQL
 * @author AGE
 * @version 2
 */
public class Sql {
    /**
     * Prepara la parte where de una cláusula para concatenar condiciones usando el OR
     * @param where parte where actual antes de su ejecución
     * @param opcion condición a incluir en el futuro where
     * @return devuelve la parte where junto con la condición enviada y concatenada según una OR
     */
    public static String rellenaWhereOR(String where, String opcion) {
        if (!opcion.equals("")){
            if (where.equals(""))
                where=opcion;
            else where+=" OR "+opcion;
        }
        return where;
    }
    /**
     * Prepara la parte where de una cláusula para concatenar condiciones usando el AND
     * @param where parte where actual antes de su ejecución
     * @param opcion condición a incluir en el futuro where
     * @return devuelve la parte where junto con la condición enviada y concatenada según una AND
     */
    public static String rellenaWhereAND(String where, String opcion) {
        if (!opcion.equals("")){
            if (where.equals(""))
                where=opcion;
            else where+=" AND "+opcion;
        }
        return where;
    }
    /**
     * Permitirá grabar el contenido de una tabla en un fichero csv
     * dentro del path
     * @param path fichero donde se grabará el contenido de la tabla
     * @param entidad nombre de la clase a importar
     * @param delimiter caracter delimitador
     */
    public static void importCSV(Path path, String entidad, char delimiter) throws Exception {
        String hql = "FROM " + entidad;
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            // Ejecutamos la consulta HQL
            List<LibroDTO> result = session.createQuery(hql, LibroDTO.class).list();

            // Escribimos la línea de la cabecera
            Field[] fields = LibroDTO.class.getDeclaredFields();
            String cabecera = Arrays.stream(fields)
                    .map(Field::getName)
                    .collect(Collectors.joining(String.valueOf(delimiter))) + "\n";
            Files.writeString(path, cabecera, StandardCharsets.UTF_8, StandardOpenOption.CREATE);

            // Escribimos las filas
            for (LibroDTO libro : result) {
                String fila = Arrays.stream(fields)
                        .map(field -> {
                            try {
                                field.setAccessible(true);
                                Object value = field.get(libro);
                                return value != null ? value.toString() : "";
                            } catch (IllegalAccessException e) {
                                return "";
                            }
                        })
                        .collect(Collectors.joining(String.valueOf(delimiter))) + "\n";
                Files.writeString(path, fila, StandardCharsets.UTF_8, StandardOpenOption.APPEND);
            }

            transaction.commit();
        }
    }
}
