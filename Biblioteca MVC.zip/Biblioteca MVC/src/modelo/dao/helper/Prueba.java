package modelo.dao.helper;

import modelo.LibroDTO;
import modelo.dao.LibroDAO;
import modelo.dao.LibroDAOImpl;

import java.util.List;

public class Prueba {
    public static void main(String[] args) {
        try {
            LibroDAO libroDAO = new LibroDAOImpl();

            // Obtener todos los libros
            List<LibroDTO> listaLibros = libroDAO.leerAllLibros();

            // Mostrar la información de cada libro
            for (LibroDTO libro : listaLibros) {
                System.out.println("ID: " + libro.getId());
                System.out.println("Nombre: " + libro.getNombre());
                System.out.println("Autor: " + libro.getAutor());
                System.out.println("Editorial: " + libro.getEditorial());
                System.out.println("Categoría: " + libro.getCategoria());
                System.out.println("-------------------------");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
