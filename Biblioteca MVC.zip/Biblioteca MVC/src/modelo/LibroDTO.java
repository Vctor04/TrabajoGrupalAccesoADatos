package modelo;

import java.io.Serializable;
import java.util.Objects;

public class LibroDTO extends Entidad {
    private int id;
    private String nombre;
    private String autor;
    private String editorial;
    private Integer categoria;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public Integer getCategoria() {
        return categoria;
    }

    public void setCategoria(Integer categoria) {
        this.categoria = categoria;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LibroDTO libroDTO = (LibroDTO) o;
        return id == libroDTO.id && Objects.equals(nombre, libroDTO.nombre) && Objects.equals(autor, libroDTO.autor) && Objects.equals(editorial, libroDTO.editorial) && Objects.equals(categoria, libroDTO.categoria);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nombre, autor, editorial, categoria);
    }
}
