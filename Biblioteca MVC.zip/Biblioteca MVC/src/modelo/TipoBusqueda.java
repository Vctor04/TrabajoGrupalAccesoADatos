package modelo;

public enum TipoBusqueda {TODOS,OR}
