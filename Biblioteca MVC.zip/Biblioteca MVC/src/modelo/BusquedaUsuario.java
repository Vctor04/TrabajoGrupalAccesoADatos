package modelo;

public class BusquedaUsuario {
    public TipoBusqueda tipo;
    public int id;
    public String nombre;
    public String apellidos;
    public int idSel=0;

}
