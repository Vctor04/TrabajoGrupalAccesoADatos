package modelo;

import modelo.dao.helper.Entidades;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;

public class PrestamosDTO extends Entidad {
    private int idPrestamo;
    private Integer idLibro;
    private Integer idUsuario;
    private Timestamp fechaPrestamo;

    public int getIdPrestamo() {
        return idPrestamo;
    }

    public void setIdPrestamo(int idPrestamo) {
        this.idPrestamo = idPrestamo;
    }

    public Integer getIdLibro() {
        return idLibro;
    }

    public void setIdLibro(Integer idLibro) {
        this.idLibro = idLibro;
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Timestamp getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(Timestamp fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PrestamosDTO that = (PrestamosDTO) o;
        return idPrestamo == that.idPrestamo && Objects.equals(idLibro, that.idLibro) && Objects.equals(idUsuario, that.idUsuario) && Objects.equals(fechaPrestamo, that.fechaPrestamo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPrestamo, idLibro, idUsuario, fechaPrestamo);
    }

    public LibroDTO getObjLibro(){
        return Entidades.libro(idLibro);
    }

    public UsuarioDTO getObjUsuario(){
        return  Entidades.usuario(idUsuario);
    }

    @Override
    public int getId() {
        return idPrestamo;
    }
}
