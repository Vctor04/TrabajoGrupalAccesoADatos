package modelo;

import modelo.dao.helper.Entidades;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PrestamosDTO extends Entidad {
    private int idPrestamo;
    private int idLibro;
    private int idUsuario;
    private LocalDateTime fechaPrestamo = LocalDateTime.now();



    // Getters y Setters

    @Override
    public int getId() {
        return idPrestamo;
    }

    public int getIdPrestamo() {
        return idPrestamo;
    }

    public void setIdPrestamo(int idPrestamo) {
        this.idPrestamo = idPrestamo;
    }

    public int getIdLibro() {
        return idLibro;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public LocalDateTime getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(LocalDateTime fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public LibroDTO getObjLibro() {
        return Entidades.libro(idLibro);
    }

    public UsuarioDTO getObjUsuario() {
        return Entidades.usuario(idUsuario);
    }
}
